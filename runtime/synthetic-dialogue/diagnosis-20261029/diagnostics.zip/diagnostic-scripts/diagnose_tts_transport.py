"""Diagnostic transport variants only; production WAV+hex request stays frozen."""
from pathlib import Path
import copy,getpass,json,sys,time
from urllib.parse import urlsplit
import requests
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from duplex_runtime.speech import sanitize,decode_wav
from duplex_runtime.user_simulator import write_json
RUN=ROOT/'runtime_runs/20261029-part4-synthetic-R01-V01-attempt4'
OUT=Path(__file__).parent/'diagnosis/transport-controls';OUT.mkdir(parents=True,exist_ok=True)
original=json.loads((RUN/'assistant-audio/A011/request.json').read_text())
endpoint='https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation'
key=getpass.getpass('DashScope API key (not stored): ')
variants=[]
request=copy.deepcopy(original);request['input']['output_format']='url';variants.append(('wav_url',request))
request=copy.deepcopy(original);request['input']['audio_setting']['format']='mp3';variants.append(('mp3_hex',request))
results=[]
for name,request in variants:
    assert request['input']['text']==original['input']['text'] and request['input']['voice_setting']==original['input']['voice_setting'] and request['model']==original['model']
    folder=OUT/name;folder.mkdir();write_json(folder/'request.json',request)
    start=time.monotonic();response=requests.post(endpoint,json=request,headers={'Authorization':'Bearer '+key},timeout=(10,90),allow_redirects=False)
    body=response.json();write_json(folder/'response.json',sanitize(body,key));output=body.get('output')or{};data=output.get('data')or{}
    result={'name':name,'diagnostic_only':True,'http_status':response.status_code,'elapsed_seconds':time.monotonic()-start,'request_id':body.get('request_id'),'base_resp':output.get('base_resp'),'rollout_request_modified':False}
    if response.status_code==200 and output.get('base_resp',{}).get('status_code')==0:
        audio=data['audio']
        if request['input'].get('output_format')=='url':
            assert urlsplit(audio).scheme=='https'
            download=requests.get(audio,timeout=(10,60),allow_redirects=False);download.raise_for_status();raw=download.content;result['download_http_status']=download.status_code
        else:raw=bytes.fromhex(audio)
        suffix=request['input']['audio_setting']['format'];(folder/('raw.'+suffix)).write_bytes(raw);result['audio_bytes']=len(raw)
        if suffix=='wav':result['frames']=len(decode_wav(raw))
        if data.get('subtitle_file'):
            sub=requests.get(data['subtitle_file'],timeout=(10,30),allow_redirects=False);sub.raise_for_status();write_json(folder/'subtitle.json',sub.json())
    else:result.update(error_code=body.get('code'),error_message=body.get('message'))
    write_json(folder/'metadata.json',result);results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
write_json(OUT/'comparison.json',results)
