"""Controlled diagnostics only; never use altered variants as rollout replacements."""
from pathlib import Path
import copy,getpass,json,sys,time
import requests
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from duplex_runtime.speech import sanitize,decode_wav
from duplex_runtime.user_simulator import write_json

ORIGINAL=ROOT/'runtime_runs/20261029-part4-synthetic-R01-V01-attempt4/assistant-audio/A011/request.json'
OUT=Path(__file__).parent/'diagnosis/factor-controls';OUT.mkdir(parents=True,exist_ok=True)
original=json.loads(ORIGINAL.read_text());endpoint='https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation'
key=getpass.getpass('DashScope API key (not stored): ')
variants=[]
request=copy.deepcopy(original);request['input'].pop('subtitle_type');request['input']['subtitle_enable']=False
variants.append(('subtitles_off',request,['input.subtitle_enable','input.subtitle_type']))
request=copy.deepcopy(original);request['input']['subtitle_type']='sentence'
variants.append(('sentence_subtitles',request,['input.subtitle_type']))
request=copy.deepcopy(original);request['input']['text']=request['input']['text'].replace('\n','')
variants.append(('word_subtitles_without_newlines',request,['input.text:remove_newlines_only']))
results=[]
for name,request,changes in variants:
    assert request['model']==original['model'] and request['input']['voice_setting']==original['input']['voice_setting'] and request['input']['audio_setting']==original['input']['audio_setting']
    folder=OUT/name;folder.mkdir();write_json(folder/'request.json',request)
    start=time.monotonic();response=requests.post(endpoint,json=request,headers={'Authorization':'Bearer '+key},timeout=(10,90),allow_redirects=False)
    body=response.json();write_json(folder/'response.json',sanitize(body,key))
    output=body.get('output')or{};data=output.get('data')or{}
    result={'name':name,'diagnostic_only':True,'changes_from_original':changes,'http_status':response.status_code,'elapsed_seconds':time.monotonic()-start,'base_resp':output.get('base_resp'),'request_id':body.get('request_id'),'rollout_request_modified':False}
    if response.status_code==200 and output.get('base_resp',{}).get('status_code')==0:
        raw=bytes.fromhex(data['audio']);pcm=decode_wav(raw);(folder/'raw.wav').write_bytes(raw);result['audio_frames']=len(pcm)
        if data.get('subtitle_file'):
            subtitle=requests.get(data['subtitle_file'],timeout=(10,30),allow_redirects=False);write_json(folder/'subtitle.json',subtitle.json())
    else:result.update(error_code=body.get('code'),error_message=body.get('message'))
    write_json(folder/'metadata.json',result);results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
write_json(OUT/'comparison.json',results)
