"""Cross-check original request after two transport variants succeeded."""
from pathlib import Path
import getpass,json,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from duplex_runtime.speech import DashScopeTTSClient,SpeechSettings
old=ROOT/'runtime_runs/20261029-part4-synthetic-R01-V01-attempt4/assistant-audio/A011/request.json'
request=json.loads(old.read_text());settings=SpeechSettings(voice_id='female-chengshu',subtitle_type='word')
assert request==settings.request(request['input']['text'])
folder=Path(__file__).parent/'diagnosis/final-original-check/assistant-audio/A011';folder.mkdir(parents=True)
client=DashScopeTTSClient(getpass.getpass('DashScope API key (not stored): '),settings)
try:
    raw=client.synthesize(request['input']['text'],folder);(folder/'raw.wav').write_bytes(raw)
    print('Original request succeeded unchanged.')
except Exception as exc:
    print(json.dumps({'original_request_unchanged':True,'error_type':type(exc).__name__,'metadata':json.loads((folder/'metadata.json').read_text())},ensure_ascii=False))
