"""User chose original request diagnosis; do not change production text/settings."""
from pathlib import Path
import getpass,hashlib,json,sys
import requests
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from duplex_runtime.speech import DashScopeTTSClient,SpeechSettings
from duplex_runtime.user_simulator import write_json

RUN=ROOT/'runtime_runs/20261029-part4-synthetic-R01-V01-attempt4'
OUT=Path(__file__).parent/'diagnosis/retest';OUT.mkdir(parents=True,exist_ok=True)
key=getpass.getpass('DashScope API key (not stored): ')
settings=SpeechSettings(voice_id='female-chengshu',subtitle_type='word')
client=DashScopeTTSClient(key,settings)
real_post=requests.post
results=[]
for original,relative in [('A010','control/A010'),('A011','assistant-audio/A011')]:
    request=json.loads((RUN/'assistant-audio'/original/'request.json').read_text())
    assert settings.request(request['input']['text'])==request
    folder=OUT/relative;folder.mkdir(parents=True)
    def capture(*args,**kwargs):
        response=real_post(*args,**kwargs)
        body=response.request.body
        if isinstance(body,str):body=body.encode()
        write_json(folder/'transport.json',{'http_status':response.status_code,
          'request_body_sha256':hashlib.sha256(body).hexdigest(),'request_body_bytes':len(body),
          'safe_response_headers':{k:v for k,v in response.headers.items()if k.lower()in {'date','content-type','content-length','x-request-id','x-dashscope-request-id','server'}}})
        return response
    requests.post=capture
    try:
        raw=client.synthesize(request['input']['text'],folder);(folder/'raw.wav').write_bytes(raw)
        result={'sample':original,'purpose':'service_positive_control'if original=='A010'else 'unchanged_failed_request_retest','status':'success'}
    except Exception as exc:
        result={'sample':original,'purpose':'service_positive_control'if original=='A010'else 'unchanged_failed_request_retest','status':'failed','error_type':type(exc).__name__}
    finally:
        requests.post=real_post
    result['metadata']=json.loads((folder/'metadata.json').read_text());result['same_original_request']=True
    results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
write_json(OUT/'comparison.json',results)
